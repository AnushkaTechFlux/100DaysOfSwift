import Cocoa

var greeting = "Hello, playground"

var beatles = ["Paul" , "John" , "Gorge"]
let numbers = [ 4 , 7 , 88, 0293]
var temperatures = [23.6 , 87.5 , 90.2]


print(beatles[0])
print(numbers[3])
print(temperatures[2])


beatles.append("Allen")
beatles.append("Viha")
print(beatles)

//temperatures.append("Christy")
print(temperatures)

let firstBeatle = beatles[0]
let firstNumber = numbers[0]
//let notAllowed = firstBeatle + firstNumber

var scores = Array<Int>()
scores.append(10)
scores.append(30)
scores.append(100)
print(scores[2])

var albums = Array<String>()
albums.append("Folklore")
albums.append("Fearless")
albums.append("Red")
print(albums[2])

var songs = [String]()
songs.append("Tujhe dekha toh yeh jaana sanam")
songs.append("Radha kaise na jalle")
songs.append("Beedi jalaaliye")
songs.append("My name is Sheela")
print(songs[3])
print(albums.count)
print(songs.count)


var character = ["Lana" , "Pam" , "Ray" , "Sterling"]
print(character.count)

character.remove(at: 2)
print(character.count)

character.removeAll()
print(character.count)


let bondMovies = ["Wall Street" , "Badrinath ki Dulhaniya" , "RomCom" , "I hate love stories" , "Laila Majnu"]
print(bondMovies.contains("Laila Majnu"))

let cities = ["Delhi" , "Lucknow" , "Kanpur" , "Agra" , "Assam" , "Bihar"]
print(cities.sorted())

let presidents = ["Bush" , "Obama" , "Trumph" , "Biden" , "Clinton"]
let reversedPresidents = presidents.reversed()
print(reversedPresidents)
print(presidents.reversed())


//store and find data in dictionaries

var employee = ["Travis Scott" , "Kyle Jenner" , "Beliie Ilish" , "Araiana Grande" , "Justin" , "Selena Gomez " , "Benny"]
print("Name : \(employee[0])")
print("Job title : \(employee[1])")
print("Location : \(employee[2])")


print("Name: \(employee[0])")
employee.remove(at: 1)
print("Job title: \(employee[1])")
print("Location: \(employee[2])")

let employee2 = ["Name" : "Taylor Swift" , "Job" : "Singer" , "Locations" : "USA" ]
print(employee2)


let employee3 = [
    "Name" : "Justin Beiber",
    "Job" : "Singer",
    "location" : "New York city"
]
print(employee3)

//print(employee2["name"])
//print(employee2["job"])
//print(employee2["location"])
//
//print(employee2["password"])
//print(employee2["status"])
//print(employee2["manager"])

print(employee2["name" , default: "Unknown"])
print(employee2["job" , default: "Unknown"])
print(employee2["location" , default: "Unknown"])

let hasGraduated = [
    "Eric" : false,
    "Ben10" : true,
    "Otis" : false
]
print(hasGraduated)

let Olympics = [
    2012 : "London",
    2016 : "India" ,
    2011 : "Tokyo"
]
print(Olympics[2012 , default: "Unknow"])

var heights = [String : Int]()
heights["Anushka"] = 18
heights["Anand"] = 80
heights["Rohan"] = 40
print(heights)

//var archEnemies = [String : Int]()
//archEnemies["Batman"] = "The Joker"
//archEnemies["Superman"] = "Lex Luthor"
//archEnemies["Batman"] = "Penguin"
//print(archEnemies)


//Why does Swift have default values for dictionaries?


let results = [
    "english": 100,
    "french": 85,
    "geography": 75
]
print(results)

let historyResult = results["history", default: 0]
print(historyResult)

//let ships = ["Star Trek", "Enterprise"]
//let enterprise = ships["Star Trek"]

//How to use sets for fast data lookup

