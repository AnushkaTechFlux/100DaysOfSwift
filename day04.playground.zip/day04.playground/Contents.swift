import Cocoa

var greeting = "Hello, playground"
let surName : String = "Sharma"
var score  : Int = 0
var scores : Double = 0

let playerName : String = "Roy"
var luckyNumber :Int = 13
let pi : Double = 3.141
var isAuthenticated : Bool = true

var albums: [String] = ["Red", "Fearless"]
var user : [String : String] = ["id" : "@Anushkarma"]

//Why would you want to create an empty collection?
let names = ["Elen" , "Chiddi" , "Thani" , "Jiyanu" , "Michel" , "Janet"]
var jNames : [String] = []

for name in names{
    if name.hasPrefix("J"){
        jNames.append(name)
    }
}
print(jNames)


var studentNames = ["Ankit" , "Tanishq" , "Aman" , "Amit" , "Ansh"]
var aNames : [String] = []
for studentName in studentNames {
    if studentName.hasPrefix("A"){
        aNames.append(studentName)
    }
}
print(aNames)


let classmates = ["Somya" , "Surya" , "Sorabh" , "Ronak" , "Rishabh" , "Shreya"]
let sNames = classmates.filter { $0.hasPrefix("A")}
print(sNames)
        
