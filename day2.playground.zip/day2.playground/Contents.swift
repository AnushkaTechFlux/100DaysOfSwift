import Cocoa

//store truth w booleans
let filename = "paris.jpg"
print(filename.hasSuffix(".jpg"))

let number = 120
print(number.isMultiple(of: 3))


let goodDogs = true
var gameOver = false
gameOver.toggle()
print(gameOver)

let isMultiple = 120.isMultiple(of: 3)
print(isMultiple)

var isAuthenticated = false
isAuthenticated = !isAuthenticated
print(isAuthenticated)
isAuthenticated = !isAuthenticated
print(isAuthenticated)


let firstPart = "Hello"
let secondPart = "World"
let greeting = firstPart + " " + secondPart
print(greeting)

let people = "Haters"
let action = "hate"
let lyric = people + " are gonna" + action
print(lyric)

let luggageCode = "1" + " " + "2"+" "+"3" + " "+"4"
print(luggageCode)


let quote = "Then he tapped a sign saying \"Believe\" and walked away."
print(quote)


let name = "Taylor"
let age = 29
let message = "Hello my name is \(name) and I'm \(age) years old."
print(message)


let numbers = 11
let missionMessage = "Apollo" + String(numbers) + " landed on the moon"
print(missionMessage)


let missionImportantMessage = "Apollo \(numbers) landed on the moon"
print(missionImportantMessage)

print("5 * 5 is \(5*5)")

let firstName = "Anushka"
let lastName = "Sharma"
var names = "\(firstName) \(lastName)"
print(names)


