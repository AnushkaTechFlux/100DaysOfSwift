import Cocoa

let celsius = 35.2
let fahrenheit = ((celsius * 9) / 5) + 32

print("\(celsius) C is \(fahrenheit) F")
