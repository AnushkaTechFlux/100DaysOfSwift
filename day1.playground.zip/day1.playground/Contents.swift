import Cocoa

var greeting = "Hello, playground"
var name = "Ted"
name = "Rebecca"
name = "Kellery"

let character = "Anushka"
//character = "Anand"

var playerName = "Roy"
print(playerName)


playerName = "Ritik"
print(playerName)

var playername = "Rohit"
print(playername)

let managerName = "Ellen"
let managername = "Suzzain"
let dogBreed = "LabraDog"


let actor = "Rajesh Khanna"
let quote = "Then he tapped a sign saying \"Believe\" and walked away."

let movie = """
A day in
the life of
an Apple Engineer
"""
print(movie)
print(movie.count)

let nameLength = actor.count
print(nameLength)


let result = "⭐You win⭐"
print(result.uppercased())
print(result.lowercased())

let filename = "photo.pdf"

print(movie.hasPrefix(("A day")))
print(filename.hasSuffix(".pdf"))

let score = 10
let reallyBig = 1_00_00_000
print(reallyBig)

let lowerCase = score - 2
let higherScore = score + 10
let doubledScore = score * 2
let squaredScore = score * score
let halvedScore = score/2

var counter = 10
counter = counter + 5
counter += 5
print(counter)

counter *= 2
counter -= 10
counter /= 2
print(counter)

let number = 150
print(number.isMultiple(of: 5))
print(180.isMultiple(of: 9))

let num = 0.1 + 0.2
print(num)

let a = 1
let b = 2.0
let c = Double(a) + b
print(c)

let double1 = 3.1
let double2 = 31.3234
let double3 = 3.0

let int1 = 3


var names = "Niha"
names = "Pagal"
//name = 7578

var rating = 5.0
rating += 2
print(rating)



