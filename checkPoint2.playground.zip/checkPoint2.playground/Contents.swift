import Cocoa

//Create an array of strings, then write code that prints:

//Total number of items in the array

//Number of unique items in the array.

let fruits = ["Apple" , "Banana" , "Kiwi" , "Cucumber" , "Berry" , "Berry"]
print("Total fruits in the array : " , fruits.count)

let uniqueFruits = Set(fruits)
print("Number of unique fruits : " , uniqueFruits.count)


//Create an array of student names.
//Print:
//
//Total number of students
//
//Number of unique student names
let students = ["Anushka" , "Anand" , "Deeptanshu" , "Vishu"]
print(students.count)

let uniqueStudents = Set(students)
print(uniqueStudents.count)

//Create an array of fruits.
//Check if "Apple" exists in the array.
let fruitNames = ["Apple" , "Guava" , "Pomegrante" , "Kiwi" , "Apple" , "Papaya"]
print(fruitNames.contains("Apple"))
